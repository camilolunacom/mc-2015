<ul class="social-networks">
	<li class="social-network"><a href="https://www.facebook.com/mor.charpentier" class="icon-facebook" target="_blank"></a></li>
	<li class="social-network"><a href="https://twitter.com/mor_charpentier" class="icon-twitter" target="_blank"></a></li>
	<li class="social-network"><a href="https://www.instagram.com/morcharpentier/" class="icon-instagram" target="_blank"></a></li>
</ul>