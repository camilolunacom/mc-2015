<footer role="contentinfo">
	<?php get_template_part('part', 'social'); ?>
	<?php get_template_part('footer-content'); ?>
</footer>