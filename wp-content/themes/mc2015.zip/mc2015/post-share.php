<div class="post-share">
	<div class="post-share-text"><?php _e( 'Share', 'mor'); ?></div>
	<ul class="social-networks">
		<li class="social-network facewindow"><a href="#" data-text="<?php echo get_the_title(); ?>" data-url="<?php the_permalink(); ?>" class="icon-facebook"></a></li>
		<li class="social-network tweetwindow"><a href="#" data-text="<?php echo get_the_title(); ?>" data-url="<?php the_permalink(); ?>" class="icon-twitter"></a></li>
	</ul>
</div>