<div class="prod-team">
	<a href="http://elmonocromo.com" target="_blank">M</a> + <a href="http://8manos.com" target="_blank">8</a>
</div>