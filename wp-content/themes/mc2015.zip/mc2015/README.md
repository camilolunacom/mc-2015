MC-2015
==========

This is the theme for mor-charpentier.com for 2015

## Features
* HTML5 elements
* Normalize.css
* HTML5shiv
* Google Analytics code
* Theme wrapper from http://scribu.net/wordpress/theme-wrappers.html
* jQuery from Google CDN