<ul class="footer-items">
	<li class="footer-item">
		<div class="line-1">61</div>
		<div class="line-2">Rue de Bretagne</div>
	</li>
	<li class="footer-item">
		<div class="line-1">Paris</div>
		<div class="line-2">75003 FR</div>
	</li>
	<li class="footer-item">
		<div class="line-1">M° Arts</div>
		<div class="line-2">et Métiers</div>
	</li>
	<li class="footer-item">
		<div class="line-1">+ 33</div>
		<div class="line-2">(0) 1 44 54 01 58</div>
	</li>
	<li class="footer-item">
		<a href="mailto:contact@mor-charpentier.com">
			<div class="line-1">contact @</div>
			<div class="line-2">mor-charpentier.com</div>
		</a>
	</li>
</ul>